package DuplaSena;
import java.util.ArrayList;

public class Aposta extends Volante{
    public static int noAposta;
    
    public Aposta(){
         noAposta++;
    }
    public int getNaposta() {
        return noAposta;
    }
    
    
    public ArrayList<Integer> acertos(Sorteio_Ramdom gerado) {
        ArrayList<Integer> acerta = new ArrayList<>(gerado.getN());
        acerta.retainAll(numeros);
        return acerta;        
    }
    
    public ArrayList<Integer> acertos2(Sorteio_Ramdom gerado) {
        ArrayList<Integer> acerta2 = new ArrayList<>(gerado.getN());
        acerta2.retainAll(numeros);
        return acerta2;        
    }
    
    public float calcPreco(int quant) {
        float preco = 0;
        switch (quant) {
            case 6:
                preco = 2.5f;
                break;
            case 7:
                preco = 17.5f;
                break;
            case 8:
                preco = 70f;
                break;
            case 9:
                preco = 210f;
                break;
            case 10:
                preco = 525f;
                break;
            case 11:
                preco = 1155f;
                break;
            case 12:
                preco = 2310f;
                break;
            case 13:
                preco = 4290f;
                break;
            case 14:
                preco = 7507.5f;
                break;
            case 15:
                preco = 12512.5f;
                break;                
        }
        return preco;
    }

}
