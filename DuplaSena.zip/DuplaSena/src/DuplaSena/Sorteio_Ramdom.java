package DuplaSena;
import java.util.Random;

public class Sorteio_Ramdom extends Volante {
    Random gera = new Random();

    public Sorteio_Ramdom() {
        int n = 0;
        while (n <= 5) {
            int sorteio = gera.nextInt(50) + 1;
            if (adiciona(sorteio)) {
                n++;
            }
        }
    }

}
