package DuplaSena;
import java.util.ArrayList;

public class Volante {

    ArrayList<Integer> numeros = new ArrayList();
    
    public ArrayList<Integer> getN() {
        return numeros;
    }

    public void remove(Integer remove) {
        numeros.remove(remove);
    }

    public boolean adiciona(Integer num) {
        if (numeros.contains(num)) {
            return false;
        } else {
            numeros.add(num);
            return true;
        }
    }  
    

    @Override
    public String toString() {
        StringBuilder saida = new StringBuilder();
        String dados = "";
        numeros.forEach((nums) -> {
            saida.append("  ").append(nums);
        });
        dados += saida;
        return dados;
    }

}
